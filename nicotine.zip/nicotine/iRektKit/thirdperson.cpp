#include "thirdperson.h"
#include "Cheat.h"
#include "SDK.h"
#include "SDK\Misc.h"

void ThirdPersonEnabled()
{
	//l8r
}