#pragma once

bool banretard();
void CheatThread();
