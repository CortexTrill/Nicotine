#pragma once

#include "SDK.h"

namespace ASUSWalls
{
	void FrameStageNotify();
}
