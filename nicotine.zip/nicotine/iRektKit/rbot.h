
class RBOT
{
public:
	//void SubmitReport(uint64_t SteamId, uint64_t MatchId);
	void SubmitReport(const char * SteamId, const char * MatchId);
};

extern RBOT report;